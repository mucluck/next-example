import Page404 from "@/pages/404";

export default Page404;
