const CityPage = ({ data }: any) => {
	return (
		<>
			Chapels
		</>
	);
};

export default CityPage;

if (process.env.NODE_ENV === "development") {
	CityPage.displayName = "CityPage";
}
