const config = require("../../next.config");

module.exports = config;
