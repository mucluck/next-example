import Dots from './Dots';

export { Dots };
