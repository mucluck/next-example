import Slider from "./Slider";

export { Slider };
