import Share from "./Share";

export { Share };
