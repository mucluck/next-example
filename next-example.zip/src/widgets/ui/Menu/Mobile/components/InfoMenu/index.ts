import InfoMenu from "./InfoMenu";

export { InfoMenu };
