import MenuHorizontal from "./MenuHorizontal";

export { MenuHorizontal };
