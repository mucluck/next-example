import { Box } from "@mantine/core";

const Header = () => {
	return (
		<Box component={"header"} itemScope itemType={"http://schema.org/WPHeader"}>
			Header
		</Box>
	);
}

export default Header;
