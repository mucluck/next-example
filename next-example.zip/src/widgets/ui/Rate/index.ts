import Rate from "./Rate";

export { Rate };
