import SearchCard from "./SearchCard";

export { SearchCard };
