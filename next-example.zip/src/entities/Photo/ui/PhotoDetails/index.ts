import PhotoDetails from "./PhotoDetails";

export { PhotoDetails };
