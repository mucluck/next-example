import CathedralDetails from "./CathedralDetails";

export { CathedralDetails };
