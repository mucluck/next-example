import AudioDetails from "./AudioDetails";

export { AudioDetails };
