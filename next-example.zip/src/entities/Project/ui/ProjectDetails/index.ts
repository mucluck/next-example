import ProjectDetails from "./ProjectDetails";

export { ProjectDetails };
