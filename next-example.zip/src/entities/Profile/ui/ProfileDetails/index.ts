import ProfileDetails from "./ProfileDetails";

export { ProfileDetails };
