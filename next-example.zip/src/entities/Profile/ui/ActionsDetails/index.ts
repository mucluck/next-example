import ActionsDetails from "./ActionsDetails";

export { ActionsDetails };
