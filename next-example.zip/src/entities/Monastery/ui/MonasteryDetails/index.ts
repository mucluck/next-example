import MonasteryDetails from "./MonasteryDetails";

export { MonasteryDetails };
