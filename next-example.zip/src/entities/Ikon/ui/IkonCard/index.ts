import IkonCard from "./IkonCard";

export { IkonCard };
