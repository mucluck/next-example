import IkonDetails from "./IkonDetails";

export { IkonDetails };
