import TourDetails from "./TourDetails";

export { TourDetails };
