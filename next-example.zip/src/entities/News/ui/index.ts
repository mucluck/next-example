export * from "./NewsCard";
export * from "./NewsDetails";
export * from "./NewsCategoryDetails";
