import NewsCard from "./NewsCard";

export { NewsCard }
