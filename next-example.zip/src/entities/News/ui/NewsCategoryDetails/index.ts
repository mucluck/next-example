import NewsCategoryDetails from "./NewsCategoryDetails";

export { NewsCategoryDetails };
