import NewsDetails from './NewsDetails';

export { NewsDetails };
