import ArticleDetails from "./ArticleDetails";

export { ArticleDetails };
