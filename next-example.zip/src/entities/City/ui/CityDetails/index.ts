import CityDetails from "./CityDetails";

export { CityDetails };
