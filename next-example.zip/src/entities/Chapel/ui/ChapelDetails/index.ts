import ChapelDetails from "./ChapelDetails";

export { ChapelDetails };
