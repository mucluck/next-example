import React from "react";

function BroadcastCard() {
	return <div>BroadcastCard</div>;
}

export default BroadcastCard;
