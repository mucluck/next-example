import BroadcastDetails from "./BroadcastDetails";

export { BroadcastDetails };
