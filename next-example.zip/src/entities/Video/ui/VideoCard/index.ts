import VideoCard from "./VideoCard";

export { VideoCard };
