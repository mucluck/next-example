import VideoDetails from "./VideoDetails";

export { VideoDetails };
