import DayPage from "./DayPage";

export { DayPage };
