import Gospel from './Gospel';

export { Gospel };
