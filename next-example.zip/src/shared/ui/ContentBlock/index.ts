import ContentBlock from './ContentBlock';

export { ContentBlock };
