import SEO from "./SEO";

export { SEO };
