import Weather from "./Weather";

export { Weather };
