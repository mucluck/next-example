import Spotlight from "./Spotlight";

export { Spotlight };
