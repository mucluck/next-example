import ContentCard from "./ContentCard";

export { ContentCard };
