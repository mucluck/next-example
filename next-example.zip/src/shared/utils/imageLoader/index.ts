const imageLoader = ({ src }: { src: string }) => {
    // console.log(all)
    return src;
}

export default imageLoader;
